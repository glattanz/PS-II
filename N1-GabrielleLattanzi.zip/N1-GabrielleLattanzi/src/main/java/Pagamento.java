public class Pagamento {

    Double valorDevido;
    Locacao locacao;
    EstadoPagamento estadoPagamento;

    public Pagamento(){
        this.estadoPagamento = EstadoPagamento.PENDENTE;
    }
}

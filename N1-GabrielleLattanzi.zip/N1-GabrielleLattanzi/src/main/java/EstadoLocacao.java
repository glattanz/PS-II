public abstract class EstadoLocacao{

    EstadoLocacao(){

    }
}

public class PgtoPendente extends Pagamento{

    public PgtoPendente(Double tamanhoContainer, Locacao locacao){
        if(tamanhoContainer<10){
            this.valorDevido = 100.0;
        }else if(tamanhoContainer<100){
            this.valorDevido = 500.0;
        }else if(tamanhoContainer<500) {
            this.valorDevido = 1000.0;
        }

        this.locacao = locacao;
    }
}

public enum EstadoPagamento {

    PENDENTE,
    CONCLUIDO
}

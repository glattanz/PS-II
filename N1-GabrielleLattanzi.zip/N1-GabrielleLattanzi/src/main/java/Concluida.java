import java.time.LocalDate;

public class Concluida extends EstadoLocacao{

    private LocalDate dataFim;

    public Concluida(){
        this.dataFim = LocalDate.now();
    }
}

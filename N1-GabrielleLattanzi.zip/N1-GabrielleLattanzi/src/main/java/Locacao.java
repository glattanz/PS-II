import java.time.LocalDate;

public class Locacao {

    private int tempoLocacao;
    private Double tamanhoContainer;
    private Cliente cliente;
    private EstadoLocacao estadoLocacao;

    public Locacao(int tempoLocacao, Double tamanhoContainer, Cliente cliente){
        this.tempoLocacao = tempoLocacao;
        this.tamanhoContainer = tamanhoContainer;
        this.cliente = cliente;
        this.estadoLocacao = new Reservada(LocalDate.now(), this);
    }

    public Locacao(Locacao locacao) {
        this.tempoLocacao = locacao.getTempoLocacao();
        this.tamanhoContainer = getTamanhoContainer();
        this.cliente = getCliente();
        this.estadoLocacao = new Reservada(LocalDate.now(), this);
    }

    public Locacao(){

    }

    public int getTempoLocacao() {
        return tempoLocacao;
    }
    public Double getTamanhoContainer() {
        return tamanhoContainer;
    }
    public Cliente getCliente() {
        return cliente;
    }
    public void setEstadoLocacao(EstadoLocacao estadoLocacao) {
        this.estadoLocacao = estadoLocacao;
    }
}

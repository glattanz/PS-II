import java.time.LocalDate;

public class Reservada extends EstadoLocacao{

    private LocalDate dataReservada;
    private LocalDate dataPrevistaFim;

    public Reservada(LocalDate dataReservada, Locacao locacao){
        this.dataReservada = dataReservada;
        this.dataPrevistaFim = dataReservada.plusDays(locacao.getTempoLocacao());
    }

    public void RealizarPagamento(Double valorPago, Locacao locacao, Pagamento pagamento){
        new PgtoConcluido(valorPago);
        locacao.setEstadoLocacao(new EmAndamento());
    }
}

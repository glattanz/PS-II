public class Cliente {

    private String nome;
    private String endereço;
    private boolean suspenso;

    public Cliente(String nome, String endereço){
        this.nome = nome;
        this.endereço = endereço;
        this.suspenso = true;
    }
}

import java.time.LocalDate;

public class PgtoConcluido extends Pagamento{

    private Double valorPago;
    private LocalDate dataPagemento;

    public PgtoConcluido(Double valorPago){
        this.valorPago = valorPago;
        this.dataPagemento = LocalDate.now();

        if(valorPago == this.valorDevido){
            this.estadoPagamento = EstadoPagamento.CONCLUIDO;
        }
    }
}

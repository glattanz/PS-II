import java.time.LocalDate;

public class EmAndamento extends EstadoLocacao{

    private LocalDate dataInicio;

    public EmAndamento(){
        this.dataInicio = LocalDate.now();
    }

    private void concluirLocacao(Locacao locacao){
            locacao.setEstadoLocacao(new Concluida());
    }
}

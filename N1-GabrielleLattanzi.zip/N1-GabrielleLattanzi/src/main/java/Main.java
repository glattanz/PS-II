public class Main {

    public static void main(String[] args) {

        Cliente cliente = new Cliente("Gabrielle", "Rua J");

        Locacao locacao = new Locacao(15, 100.0, cliente);
    }
}

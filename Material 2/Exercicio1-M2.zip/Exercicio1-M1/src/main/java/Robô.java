public class Robô implements Controle{

    public void andar(){
        System.out.println("Andando...");
    }

    public void virar(){
        System.out.println("Virando...");
    }

    public void falar(){
        System.out.println("Falando...");
    }
}

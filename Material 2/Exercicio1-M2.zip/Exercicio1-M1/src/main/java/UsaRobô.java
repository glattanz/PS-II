public class UsaRobô extends Robô{

    public static void main(String[] args) {

        Robô r1 = new Robô();

        r1.andar();
        r1.falar();
        r1.virar();
        
    }
}
